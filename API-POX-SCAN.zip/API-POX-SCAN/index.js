const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Set storage engine
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

// Init upload
const upload = multer({
  storage: storage,
  limits: { fileSize: 1000000 }, // 1MB limit
  fileFilter: function (req, file, cb) {
    checkFileType(file, cb);
  }
}).single('image');

// Check file type
function checkFileType(file, cb) {
  const filetypes = /jpeg|jpg|png|gif/;
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = filetypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb('Error: Images Only!');
  }
}

// Upload endpoint
app.post('/upload', (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      res.status(400).json({ success: false, message: err });
    } else {
      if (req.file == undefined) {
        res.status(400).json({ success: false, message: 'No file selected!' });
      } else {
        // Simulate sending the image to an ML service and getting a response
        const imagePath = req.file.path;
        const analysisResult = analyzeImage(imagePath); // Placeholder function

        res.status(200).json({
          success: true,
          message: 'File uploaded!',
          file: req.file,
          analysisResult: analysisResult
        });
      }
    }
  });
});

// Placeholder function to simulate image analysis
function analyzeImage(imagePath) {
  // Here you would have your ML logic to analyze the image
  // For this example, let's just return a dummy result
  return {
    imagePath: imagePath,
    analysis: "This is a simulated analysis result."
  };
}

// Get analysis result endpoint
app.get('/analysis/:filename', (req, res) => {
  const filename = req.params.filename;
  const imagePath = path.join(__dirname, 'uploads', filename);
  
  if (fs.existsSync(imagePath)) {
    const analysisResult = analyzeImage(imagePath); // Placeholder function
    res.status(200).json({
      success: true,
      analysisResult: analysisResult
    });
  } else {
    res.status(404).json({ success: false, message: 'File not found!' });
  }
});

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
